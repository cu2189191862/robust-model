# dependencies
from robustoptimization.robustlinearmodel import RobustLinearModel
from robustoptimization.util.linearexpression import LinearExpression
from robustoptimization.util.uncertaintyset import uncertaintyset
from robustoptimization.util.variable import Variable
from robustoptimization.util.parameter import Parameter
from robustoptimization.util.uncertaintyset.box import Box
from robustoptimization.util.uncertaintyset.ball import Ball

from datetime import datetime

import os
import random


# configurations
start_timestamp = datetime.now().strftime("%d_%m_%Y_%H:%M:%S")
log_path = os.path.join(".", "logs", start_timestamp + ".txt")
to_log = True
random.seed(5)

# initialization
rm = RobustLinearModel(log_path=log_path)
rm.name = "Test case"


# setup
'''
N = {1, 2}
c = [c_1, c_2]
d = d
A = 
    [
        [a_1_1, a_1_2], # for constraint 1
        [a_2_1, a_2_2], # for constraint 2
    ]
x = [x_1, x_2]
b = [b_1, b_2]
'''
constraint_count = 2

rm.sets["N"] = set(range(2))

c = [Parameter("c_{}".format(n), uncertain=False, value=1)
     for n in rm.sets["N"]]
d = Parameter("d", uncertain=False, value=1)  # d

A = [[Parameter("a_{}_{}".format(i, j), uncertain=True)
      for j in rm.sets["N"]] for i in range(constraint_count)]

x = [Variable("x_{}".format(n), lower_bound=0, upper_bound=1,
              type_="continuous") for n in rm.sets["N"]]
b = [Parameter("b_{}".format(i), uncertain=True)
     for i in range(constraint_count)]
U = [Box(robustness=1,
         nominal_data={A[0][n]: Parameter("{}_nominal".format(
             A[0][n].name), uncertain=False, value=1) for n in rm.sets["N"]},
         base_shifts=[{A[0][n]: Parameter("{}_shift_{}".format(A[0][n].name, data), uncertain=False, value=random.uniform(-0.1, 0.1)) for n in rm.sets["N"]} for data in range(5)]),
     Box(robustness=1,
         nominal_data={A[1][n]: Parameter("{}_nominal".format(
             A[1][n].name), uncertain=False, value=1) for n in rm.sets["N"]},
         base_shifts=[{A[1][n]: Parameter("{}_shift_{}".format(A[1][n].name, data), uncertain=False, value=random.uniform(-0.1, 0.1)) for n in rm.sets["N"]} for data in range(5)])]
# todo optimize structure
for i in range(constraint_count):
    U[i].nominal_data[b[i]] = Parameter(
        "{}_nominal".format(b[i].name), uncertain=False, value=1)
    for idx, data in enumerate(U[i].base_shifts):
        data[b[i]] = Parameter("{}_shift_{}".format(
            b[i].name, idx), uncertain=False, value=random.uniform(-0.1, 0.1))


# core
rm.add_variables(x)
obj_func = LinearExpression({x[n]: c[n] for n in range(len(rm.sets["N"]))})
rm.set_objective_function(obj_func, "minimize")

for i in range(constraint_count):
    expression = LinearExpression({x[j]: A[i][j] for j in range(
        len(rm.sets["N"]))}, sense="<=", rhs=b[i])
    rm.add_constraint("c{}".format(i), expression, U[i])

rm.transform()


if to_log:
    rm.dump_configs()
    rm.dump_transformed()
