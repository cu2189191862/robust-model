from robustoptimization.util.uncertaintyset.uncertaintyset import UncertaintySet


class Box(UncertaintySet):
    pass
