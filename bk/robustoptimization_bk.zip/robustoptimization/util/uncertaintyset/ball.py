from robustoptimization.util.uncertaintyset.uncertaintyset import UncertaintySet


class Ball(UncertaintySet):
    pass
