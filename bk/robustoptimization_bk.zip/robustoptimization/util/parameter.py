
class Parameter:

    # , in_uncertainty_set=None):
    def __init__(self, name, uncertain: bool = False, value=None):
        # if uncertain and in_uncertainty_set == None:
        #     raise ValueError("please specify uncertainty set.")
        # todo check is subclass
        self.name = name
        self.uncertain = uncertain
        self.value = value
        # self.in_uncertainty_set = in_uncertainty_set

    pass
