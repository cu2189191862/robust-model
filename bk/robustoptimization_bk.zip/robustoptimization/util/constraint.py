from robustoptimization.util.linearexpression import LinearExpression
from robustoptimization.util.parameter import Parameter
from robustoptimization.util.uncertaintyset.box import Box
from robustoptimization.util.uncertaintyset.ball import Ball
from robustoptimization.util.variable import Variable

import numpy as np


class Constraint:
    def __init__(self, name: str, expression: LinearExpression, uncertain: bool, uncertainty_set=None):
        self.name = name
        self.expression = expression
        self.uncertain = uncertain
        self.uncertainty_set = uncertainty_set
        self.__description = None

    def transform(self):
        '''
        Returns:
            list of Constraint objs
        '''
        if self.uncertain:
            type_ = type(self.uncertainty_set)
            if type_ == Box:
                return self.__box_transform()
            elif type_ == Ball:
                return self.__ball_transform()
        else:
            return [self]

    def __box_transform(self):
        '''
        '{id}@{orginal_constraint_name}': {id} of transformed constraint from {original constraint}
        '''
        transformed_count = 0
        new_constraints = list()
        one = Parameter("1", uncertain=False, value=1)  # 1
        minus_one = Parameter("-1".format(self.name),
                              uncertain=False, value=-1)  # -1
        # p18 implementation (1.3.8)
        # main part
        # a_0 x + sum(u_l) <= b_0
        name = "{}@{}".format(transformed_count, self.name)
        xs = list(self.expression.lhs.keys())
        us = [Variable("u_{}@{}".format(l, self.name), lower_bound=0, upper_bound=np.inf,
                       type_="continuous") for l in range(len(self.uncertainty_set.base_shifts))]
        coefficients = {  # coefficients of x
            x: self.uncertainty_set.nominal_data[self.expression.lhs[x]] for x in xs}
        coefficients.update({u: one for u in us})  # coefficient of u_l

        expression = LinearExpression(
            coefficients, sense="<=", rhs=self.uncertainty_set.nominal_data[self.expression.rhs])
        transformed = Constraint(name, expression, uncertain=False)
        transformed.__description = "box transform: a_nominal x + sum_over_L(u_l) <= b_nominal"
        new_constraints.append(transformed)
        transformed_count += 1

        # abs part (linearization)
        # -u_l <= a_l x - b_l <= u_l, for all l in L
        # -> -u_l - a_l x <= -b_l for all l in L (negative constraint)
        # -> a_l x - u_l  <= b_l for all l in L (positive constraint)

        for l in range(len(self.uncertainty_set.base_shifts)):
            # negative -u_l - a_l x <= -b_l
            name = "{}@{}".format(transformed_count, self.name)
            coefficients = {x: Parameter(
                "-{}".format(self.uncertainty_set.base_shifts[l]
                             [self.expression.lhs[x]].name),
                uncertain=False, value=-self.uncertainty_set.base_shifts[l][self.expression.lhs[x]].value) for x in xs}
            coefficients.update({us[l]: minus_one})
            rhs = Parameter(
                "-{}".format(self.uncertainty_set.base_shifts[l]
                             [self.expression.rhs].name),
                uncertain=False, value=-self.uncertainty_set.base_shifts[l][self.expression.rhs].value)
            expression = LinearExpression(
                lhs=coefficients, sense="<=", rhs=rhs)
            transformed = Constraint(
                name, expression, uncertain=False)
            transformed.__description = "box transform: -u_{} - a_data{} x <= -b_{}".format(
                l, l, l)
            new_constraints.append(transformed)
            transformed_count += 1

            # positive a_l x - u_l  <= b_l
            name = "{}@{}".format(transformed_count, self.name)
            coefficients = {
                x: self.uncertainty_set.base_shifts[l][self.expression.lhs[x]] for x in xs}
            coefficients.update({us[l]: minus_one})
            rhs = self.uncertainty_set.base_shifts[l][self.expression.rhs]
            expression = LinearExpression(
                lhs=coefficients, sense="<=", rhs=rhs)
            transformed = Constraint(
                name, expression, uncertain=False)
            transformed.__description = "box transform: a_data{} x - u_{} <= b_{}".format(
                l, l, l)
            new_constraints.append(transformed)
            transformed_count += 1

        return new_constraints

    def __ball_transform(self):

        raise NotImplementedError()

    def get_human_readable(self):
        readable = ""
        readable += "\t{}: {}\n".format(
            self.name, self.expression.get_human_readable())
        if self.__description != None:
            readable += "\t\tdescription: {}\n".format(self.__description)
        readable += "\t\tparameters:\n"

        if self.uncertain:
            readable += "\t\t\t{}\n".format(
                type(self.uncertainty_set).__name__)
            readable += self.uncertainty_set.get_human_readable()
        else:
            for key in self.expression.lhs:
                coefficient = self.expression.lhs[key]
                readable += "\t\t\t{} = {}\n".format(
                    coefficient.name, coefficient.value)
            readable += "\t\t\t{} = {}\n".format(
                self.expression.rhs.name, self.expression.rhs.value)

        return readable
