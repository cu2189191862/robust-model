from copy import deepcopy


class LinearExpression:
    def __init__(self, lhs=dict(), sense=None, rhs=None):
        if sense != None and sense != ">=" and sense != "<=":
            raise ValueError("Unsupported sense.")
        self.lhs = lhs
        self.sense = sense
        self.rhs = rhs

    def is_filled(self):
        if self.sense == None or self.lhs == None or self.rhs == None:
            return False
        else:
            return True

    def only_lhs(self):
        if self.sense != None or self.rhs != None:
            return False
        return True

    def __add__(self, to_add):
        if type(to_add).__name__ != "LinearExpression":
            raise TypeError()
        if (not self.only_lhs()) or (not to_add.only_lhs()):
            raise ValueError(
                "Only expression without sense and rhs can be operated.")

        result = LinearExpression()
        result.lhs = deepcopy(self.lhs)
        result.rhs = deepcopy(self.rhs)
        result.sense = deepcopy(self.sense)
        for var in to_add.lhs:
            if var in result.lhs:
                result.lhs[var] += to_add.lhs[var]
            else:
                result.lhs[var] = to_add.lhs[var]
        return result

    def __iadd__(self, to_add):
        if type(to_add).__name__ != "LinearExpression":
            raise TypeError()
        if (not self.only_lhs()) or (not to_add.only_lhs()):
            raise ValueError(
                "Only expression without sense and rhs can be operated.")

        for var in to_add.lhs:
            if var in self.lhs:
                self.lhs[var] += to_add.lhs[var]
            else:
                self.lhs[var] = to_add.lhs[var]
        return self

    def get_human_readable(self):  # , precision: int = 4):
        human_readable = ""
        var_objs = list(self.lhs.keys())
        if self.lhs[var_objs[0]].uncertain:
            human_readable += "@{} * {}".format(
                self.lhs[var_objs[0]].name, var_objs[0].name)
        else:
            human_readable += "{} * {}".format(
                self.lhs[var_objs[0]].name, var_objs[0].name)
        for var_obj in var_objs[1:]:
            coefficient = self.lhs[var_obj]
            if coefficient.uncertain:
                human_readable += " + @{} * {}".format(
                    coefficient.name, var_obj.name)
            else:
                human_readable += " + {} * {}".format(
                    coefficient.name, var_obj.name)

        if self.is_filled():
            if self.rhs.uncertain:
                human_readable += " {} @{}".format(self.sense,
                                                   self.rhs.name)
            else:
                human_readable += " {} {}".format(self.sense,
                                                  self.rhs.name)
        return human_readable

    def display(self):
        print(self.get_human_readable())
