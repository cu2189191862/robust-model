class Variable:
    def __init__(self, name: str, lower_bound, upper_bound, type_):
        self.name = name
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound
        self.type_ = type_
