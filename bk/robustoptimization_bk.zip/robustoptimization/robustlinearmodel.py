from datetime import datetime
from os import name
from robustoptimization.util.uncertaintyset.box import Box
from robustoptimization.util.constraint import Constraint
from robustoptimization.util.linearexpression import LinearExpression
# from robustoptimization.util.variable import Variable


class RobustLinearModel:
    def __init__(self, log_path):
        self.name = None
        self.established_time = datetime.now().strftime("%d_%m_%Y_%H:%M:%S")
        self.sets = dict()
        self.sense = None
        self.__variables = dict()
        self.__objective_function = None
        self.__constraints = dict()
        self.parameters = dict()
        self.transformed_constraints = dict()
        self.__log_writer = open(log_path, "a")

    # def var(self, key):
    #     return self.__variables[key]

    def add_variables(self, varaibles):
        '''
        Parameters:
            variables ([Variables]): list of variables
        '''
        for variable in varaibles:
            if variable.name not in self.__variables:
                self.__variables[variable.name] = variable
            else:
                raise ValueError("variable name already exist.")

    def set_objective_function(self, expression: LinearExpression, sense="minimize"):
        if expression.only_lhs() and (sense == "minimize" or sense == "maximize"):
            self.__objective_function = expression
            self.sense = sense
        else:
            raise ValueError(
                "Only expression without sense and rhs can be assigned.")

    def add_constraint(self, name=None, expression: LinearExpression = None, uncertainty_set=None):
        if expression.is_filled():
            if name == None:
                name = "c{}".format(len(self.__constraints))

            uncertain = False
            # uncertain_count = 0
            for var in expression.lhs:
                coefficient = expression.lhs[var]
                if coefficient.uncertain:
                    uncertain = True
            if expression.rhs.uncertain:
                uncertain = True

            if uncertain and uncertainty_set == None:
                raise ValueError("please specify uncertainty set")
            self.__constraints[name] = Constraint(
                name, expression, uncertain, uncertainty_set)

        else:
            raise ValueError(
                "Right hand side or sense missed in expression parameter.")

        # uncertainty_set.set_variable_count(len(expression.lhs))

    def __del__(self):
        self.__log_writer.close()

    def display(self):
        raise NotImplementedError()

    def __log(self, log_str):
        self.__log_writer.write(log_str)

    def dump_configs(self):
        # meta info.
        self.__log("Model name: {}\n".format(self.name))
        self.__log("Established time: {}\n".format(self.established_time))

        # set
        self.__log("Sets:\n")
        for s in self.sets:
            self.__log("\t{}: {}\n".format(s, self.sets[s]))

        # # parameters
        # self.__log("Parameters:\n")
        # for p in self.parameters:
        #     self.__log("\t{}: {}\n".format(p, self.parameters[p]))

        # variables
        self.__log("Variables:\n")
        for key in self.__variables:
            v = self.__variables[key]
            self.__log("\t{}: lb={}\tub={}\ttype_={}\n".format(
                v.name, v.lower_bound, v.upper_bound, v.type_))

        # objective function
        self.__log("Objective function:\n")
        self.__log("\t{}: {}\n".format(
            self.sense, self.__objective_function.get_human_readable()))

        # constraints
        self.__log("Constraints:\n")
        for key in self.__constraints:
            c = self.__constraints[key]
            self.__log(c.get_human_readable())

        self.__log(
            "==========================================================end config.============================================================\n")

    def dump_transformed(self):
        for original_name in self.transformed_constraints:
            for new_constraint in self.transformed_constraints[original_name]:
                self.__log(new_constraint.get_human_readable())

    def transform(self):
        for constraint_name in self.__constraints:
            self.transformed_constraints[constraint_name] = self.__constraints[constraint_name].transform(
            )

    # def __variable_key_to_str(self, variable_key):
    #     name = "{}_".format(variable_key[0])
    #     for i in variable_key[1:]:
    #         name += str(i)
    #     return name
