SOCP implementation
https://support.gurobi.com/hc/en-us/community/posts/360056340871-Implementing-SOCP-Constraints-Using-Python


todo:
constant in objective
uncertainty in objective
ball uncertainty